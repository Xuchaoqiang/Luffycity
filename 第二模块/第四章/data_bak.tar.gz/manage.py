#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Irving

from crm import views

views.view()