#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author:Irving


def setting():
    print(' in the settings!')